#ifndef _BUILDTREE_
#define _BUILDTREE_

Node *makeNode(double x, double y, int level);
void makeChildren(Node *parent);

#endif
