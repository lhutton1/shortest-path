#ifndef _DESTROYTREE_
#define _DESTROYTREE_

void destroyTree(Node *head);
void destroyNode(Node *node);

#endif
