#ifndef _TESTS_
#define _TESTS_

extern const int MAX_LEVEL;
void task1();
void task2();
void task3();
void task4();

#endif
