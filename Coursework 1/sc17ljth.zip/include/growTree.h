#ifndef _GROWTREE_
#define _GROWTREE_

void growTree(Node *head);
void growNode(Node *node);

#endif
