#ifndef __HANDLEERROR__
#define __HANDLEERROR__

void throwError(char *errorMsg);

#endif
