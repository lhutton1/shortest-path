#include <stdio.h>
#include <stdlib.h>

#include "uthash.h"
#include "buildNetwork.h"
#include "networkStructure.h"

const int MAX_NODES = 4000;

// Add new adjacency node to the graph with specified id
AdjListNodeP createAdjacencyNode(int nodeNo) {
  AdjListNodeP newNode = (AdjListNodeP)malloc(sizeof(AdjListNode));

  if (!newNode) {
    printf("New node could not be created, unable to allocate needed memory");
    return NULL;
  }

  newNode->node = nodeNo;

  return newNode;
}


// Create new empty graph allocating adjacency nodes with no data
NetworkP createNetwork() {
  NetworkP newNetwork = (NetworkP)malloc(sizeof(Network));

  if (!newNetwork) {
    printf("New network could not be created, unable to allocate needed memory");
    return NULL;
  }

  newNetwork->noNodes = 0;
  newNetwork->adjacencyListArray = (AdjListP)malloc(MAX_NODES * sizeof(AdjList));
  newNetwork->nodesHashTable = NULL;

  if (!newNetwork->adjacencyListArray) {
    printf("New adjacency lisy array could not be created, unable to allocate needed memory");
    return NULL;
  }

  for (int x = 0; x < MAX_NODES; ++x) {
    newNetwork->adjacencyListArray[x].head = NULL;
    newNetwork->adjacencyListArray[x].noMembers = 0;
  }

  return newNetwork;
}


// Destroy graph, first removing adjacency nodes, then the adjacency array,
// then the network itself freeing up all memory.
void destroyNetwork(NetworkP network) {
  if (network) {
    if (network->adjacencyListArray) {
      for (int x = 0; x < network->noNodes; ++x) {
        AdjListNodeP head = network->adjacencyListArray[x].head;

        while (head) {
          AdjListNodeP temp = head;
          head = head->next;
          free(temp);
        }
      }
      free(network->adjacencyListArray);
    }
    free(network);
  }
}


// Add new node to the network by adding the relevent data to a free
// adjacency node. Also add this node to a hash table so it can
// be quickly found.
void addNode(NetworkP network, int id, double x, double y) {
  if (network->noNodes > MAX_NODES) {
    printf("Limit reached\n");
    return;
  }

  AdjListP newNode = &network->adjacencyListArray[network->noNodes];

  //Initialse new nodes properties
  newNode->noMembers = 0;
  newNode->id = id;
  newNode->x = x;
  newNode->y = y;
  newNode->head = NULL;

  HASH_ADD_INT(network->nodesHashTable, id, newNode);

  network->noNodes++;
}


// Create a new adjacent node to add to adjacency list
// node and initialze default values.
AdjListNodeP createNode(AdjListP node, double weight) {
    AdjListNodeP newAdjNode = (AdjListNodeP)malloc(sizeof(AdjListNode));

    if(!newAdjNode)
        printf("Unable to allocate memory for new node\n");

    newAdjNode->node = node->id;
    newAdjNode->weight = weight;
    newAdjNode->next = NULL;

    return newAdjNode;
}


// Add an edge to the network. Adds source node to the target in
// adjacency array and visa versa, using a linked list to keep
// track of changes.
void addEdge(NetworkP network, int id, int source, int target, double weight) {
  AdjListP sourceNode;
  AdjListP targetNode;

  HASH_FIND_INT(network->nodesHashTable, &source, sourceNode);
  HASH_FIND_INT(network->nodesHashTable, &target, targetNode);

  // Add node to adjacency list for source -> target (source | target, ...)
  AdjListNodeP newAdjNode = createNode(targetNode, weight);
  newAdjNode->next = sourceNode->head;
  sourceNode->head = newAdjNode;
  sourceNode->noMembers++;

  // Add node to adjacency list for target -> source (target | source, ...)
  newAdjNode = createNode(sourceNode, weight);
  newAdjNode->next = targetNode->head;
  targetNode->head = newAdjNode;
  targetNode->noMembers++;
}
